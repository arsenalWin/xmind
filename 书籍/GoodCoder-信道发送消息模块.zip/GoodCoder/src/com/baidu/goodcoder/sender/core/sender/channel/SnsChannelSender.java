package com.baidu.goodcoder.sender.core.sender.channel;

import com.baidu.goodcoder.sender.core.message.BaseMessage;
import com.baidu.goodcoder.sender.core.sender.QueueMessageSender;
import com.baidu.goodcoder.sender.core.util.Frequency;

/**
 * Created by luzhiming on 2017/10/30.
 * 短信信道
 */
public class SnsChannelSender extends QueueMessageSender {
    private static final Frequency defaultFrequency = new Frequency(100, 1);
    private static final SnsChannelSender instance = new SnsChannelSender();

    @Override
    public void channelSend(BaseMessage baseMessage) {
        System.out.println("短信信道 发送消息的具体业务逻辑， 发送的消息是:" + baseMessage.format());
    }

    @Override
    public Frequency getFrequency() {
        return defaultFrequency;
    }

    @Override
    public String getChannelKey() {
        return "SNS_CHANNEL";
    }


}
