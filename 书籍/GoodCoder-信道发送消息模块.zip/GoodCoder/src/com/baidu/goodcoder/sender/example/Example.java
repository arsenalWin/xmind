package com.baidu.goodcoder.sender.example;

import com.baidu.goodcoder.sender.core.util.SenderUtils;
import com.baidu.goodcoder.sender.core.sender.channel.EmailChannelSender;
import com.baidu.goodcoder.sender.core.sender.channel.SnsChannelSender;

/**
 * Created by luzhiming on 2017/10/30.
 */
public class Example {
    public static void main(String[] args) throws InstantiationException, IllegalAccessException {
        SenderUtils senderUtils = SenderUtils.getInstance().addMessageSender(EmailChannelSender.class);
        senderUtils.sendMessage(new TextMessage().setInfo("HelloWorld"));
    }
}
