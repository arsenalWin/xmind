package com.baidu.goodcoder.sender.core.sender.channel;

import com.baidu.goodcoder.sender.core.message.BaseMessage;
import com.baidu.goodcoder.sender.core.util.Frequency;
import com.baidu.goodcoder.sender.core.sender.QueueMessageSender;

/**
 * Created by luzhiming on 2017/10/30.
 * 邮件信道
 */
public class EmailChannelSender extends QueueMessageSender {
    private static final Frequency defaultFrequency = new Frequency(40, 1);

    @Override
    public void channelSend(BaseMessage baseMessage) {
        System.out.println("邮件信道 发送消息的具体业务逻辑， 发送的消息是:" + baseMessage.format());
    }

    @Override
    public Frequency getFrequency() {
        return defaultFrequency;
    }

    @Override
    public String getChannelKey() {
        return "EMAIL_CHANNEL";
    }
}
