package com.baidu.goodcoder.sender.core.sender;

import com.baidu.goodcoder.sender.core.message.BaseMessage;
import com.baidu.goodcoder.sender.core.util.Frequency;
import com.baidu.goodcoder.sender.core.util.RedisClient;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by luzhiming on 2017/10/30
 *
 * 信道这部分的设计采用<模板方法设计模式>来设计，每个具体的信道需要实现
 * 子类需要实现如下几个方法：
 * {@link #channelSend(BaseMessage)} 信道发送消息的具体业务逻辑
 * {@link #getFrequency()} 返回该信道的频率，具体的请看{@link Frequency}
 * {@link #getChannelKey()} 返回该新到的Key，由于用Redis实现频率控制，所以Key要请不能相同
 *
 */
public abstract class QueueMessageSender extends BaseMessageSender {
    private LinkedBlockingQueue<BaseMessage> messageQueue = new LinkedBlockingQueue<BaseMessage>();
    private RedisClient redisClient = new RedisClient();

    private AtomicBoolean flag = new AtomicBoolean(true);

    /**
     * 检查是否符合频率限制 {@link Frequency}
     * @return
     */
    private boolean checkFrequency() {
        Frequency frequency = getFrequency();
        frequency.getFrequencyCount();
        int inc = redisClient.get(getChannelKey());
        if (inc == 1) {
            redisClient.setLiveTime(getChannelKey(), frequency.getFrequencySeconds());
            return true;
        }
        if (inc >= frequency.getFrequencyCount()) {
            return false;
        }
        return true;
    }

    /**
     * 具体通道的发送业务逻辑
     *
     * @param baseMessage
     */
    public abstract void channelSend(BaseMessage baseMessage);

    /**
     * 获得频率限制 {@link Frequency}
     * @return
     */
    public abstract Frequency getFrequency();

    /**
     * 返回该新到的Key，由于用Redis实现频率控制，所以Key要请不能相同
     * @return
     */
    public abstract String getChannelKey();

    /**
     * 异步发送，首先将消息放到队列中
     * @param baseMessage
     */
    @Override
    public void send(BaseMessage baseMessage) {
        if(!flag.get()){
            System.out.println("队列正在关闭或已经关闭");
            return;
        }
        messageQueue.add(baseMessage);
    }

    /**
     * 递增频率
     */
    private void addFrequency() {
        redisClient.inc(getChannelKey());
    }

    @Override
    public void run() {
        while (flag.get() || !messageQueue.isEmpty()) {
            if (checkFrequency()) {
                addFrequency();
                BaseMessage message = null;
                try {
                    message = messageQueue.take();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                channelSend(message);
                log(message);
            }
        }
    }

    /**
     * 优雅的关闭
     */
    @Override
    public void stopSender() {
        flag.set(false);
    }

    /**
     * 打印日志
     * @param message
     */
    private void log(BaseMessage message) {
        System.out.println("The channel is " + getChannelKey()
                + ",The Frequency count :" + getFrequency().getFrequencyCount() + " , seconds:" + getFrequency().getFrequencySeconds()
                + ",The message is :" + message.format() + " ,is send by " + getChannelKey());
    }
}
