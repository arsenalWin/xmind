package com.baidu.goodcoder.sender.core.message;

/**
 * Created by luzhiming on 2017/10/30.
 * 信息的超类
 */
public abstract class BaseMessage {
    /**
     * 格式化信息的输出
     *
     * @return
     */
    public abstract String format();
}
