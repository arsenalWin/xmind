package com.baidu.goodcoder.sender.example;

import com.baidu.goodcoder.sender.core.message.BaseMessage;

/**
 * Created by luzhiming on 2017/10/30.
 */
public class TextMessage extends BaseMessage {
    public String getInfo() {
        return info;
    }

    public TextMessage setInfo(String info) {
        this.info = info;
        return this;
    }

    private String info;

    @Override
    public String format() {
        return info;
    }
}
