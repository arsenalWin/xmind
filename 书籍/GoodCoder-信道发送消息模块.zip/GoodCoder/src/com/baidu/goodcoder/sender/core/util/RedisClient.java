package com.baidu.goodcoder.sender.core.util;

/**
 * Created by luzhiming on 2017/10/30
 * 模拟Redis客户端.
 */
public class RedisClient {
    public int inc(String key) {
        return 1;
    }

    public int get(String key) {
        return 1;
    }

    public void setLiveTime(String key, Integer seconds) {

    }
}
