package com.baidu.goodcoder.sender.core.util;

import com.baidu.goodcoder.sender.core.message.BaseMessage;
import com.baidu.goodcoder.sender.core.sender.BaseMessageSender;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by luzhiming on 2017/10/30.
 * 发送消息调度器，采用了<单例模式>，<观察者设计模式> 和 <方法链>的设计思路
 * <单例模式>:消息调度器一个JVM中智能有一个实例,通过{@link #getInstance()} 获取实例
 * <观察者设计模式>:消息和信道之间是观察者设计模式，一个消息可以发送给多个通道。
 * <方法链>:本类多个方法的返回值均为this，方便用方法链的方式调用方法
 */
public class SenderUtils {
    private Map<Class<? extends BaseMessageSender>, BaseMessageSender> senders = new ConcurrentHashMap<>();
    private static final SenderUtils instance = new SenderUtils();

    private SenderUtils() {
    }

    /**
     * 获取实例，单例模式
     * @return
     */
    public static final SenderUtils getInstance() {
        return instance;
    }

    /**
     * 添加消息处理通道
     * @param messageSender
     * @return
     * @throws IllegalAccessException
     * @throws InstantiationException
     */
    public SenderUtils addMessageSender(Class<? extends BaseMessageSender> messageSender) throws IllegalAccessException, InstantiationException {
        if (senders.containsKey(messageSender)) {
            return this;
        }
        BaseMessageSender sender = messageSender.newInstance();
        sender.start();
        senders.put(messageSender, sender);
        return this;
    }

    /**
     * 优雅的移除关闭某个通道
     * @param messageSender
     * @return
     */
    public SenderUtils removeMessageSender(BaseMessageSender messageSender) {
        //优雅的remove,保证不在接收消息，但是已经接收的消息应该处理完毕
        messageSender.stopSender();
        senders.remove(messageSender);
        return this;
    }

    /**
     * 发送消息
     * @param baseMessage
     * @return
     */
    public SenderUtils sendMessage(BaseMessage baseMessage) {
        senders.values().forEach(sender -> {
            sender.send(baseMessage);
        });
        return this;
    }
}