package com.baidu.goodcoder.sender.core.util;

import java.nio.IntBuffer;

/**
 * Created by luzhiming on 2017/10/17.
 * 频率限制 公式为 frequencyCount/frequencySeconds
 *
 */
public class Frequency {
    /**
     * 频率数量限制
     */
    private Integer frequencyCount;

    /**
     * 频率时间限制，单位:秒
     */
    private Integer frequencySeconds;


    public Frequency(int frequencyCount, int frequencySeconds) {
        this.frequencyCount = frequencyCount;
        this.frequencySeconds = frequencySeconds;
    }

    public Integer getFrequencyCount() {
        return frequencyCount;
    }

    public void setFrequencyCount(Integer frequencyCount) {
        this.frequencyCount = frequencyCount;
    }

    public Integer getFrequencySeconds() {
        return frequencySeconds;
    }

    public void setFrequencySeconds(Integer frequencySeconds) {
        this.frequencySeconds = frequencySeconds;
    }
}
