package com.baidu.goodcoder.sender.core.sender;

import com.baidu.goodcoder.sender.core.message.BaseMessage;

/**
 * Created by luzhiming on 2017/10/30.
 * 信道超类
 *
 */
public abstract class BaseMessageSender extends Thread{
    public abstract void send(BaseMessage baseMessage);
    public abstract void stopSender();
}
